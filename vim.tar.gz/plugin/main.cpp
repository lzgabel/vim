/*************************************************************************
	> File Name: main.cpp
	> Author: 
	> Mail: 
	> Function: 
	> Remark: 
	> Created Time: 2017年09月20日 星期三 21时19分38秒

 ************************************************************************/

#include<bits/stdc++.h>
using namespace std;
class Main
{
    public :
        int a, b;
};
int main(int argc,char *argv[])
{

}

