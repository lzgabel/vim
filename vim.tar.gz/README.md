# 超强vim配置文件

[![Build Status](https://travis-ci.org/ma6174/vim.png?branch=master)](https://travis-ci.org/ma6174/vim)

### 运行截图

![screenshot.png](screenshot.png)

### 简易安装方法：
- 直接将项目克隆到本地即可
- `配置是结合tmux, vim, zsh， 当然您也可以更改文件配置.tmux.conf将其更换为bash`
- `sudo apt install tmux , vim, zsh`
- `sh -c "$(wget https://raw.github.com/robbyrussell/oh-my-zsh/master/tools/install.sh -O -)" 安装oh-my-zsh`
- `cd ~`
-  `git clone http://github.com/gmarik/vundle.git ~/.vim/bundle/vundle`
- `git clone https://git.coding.net/AKFScorpion/vim-tmux.git .vim`
- `mv ~/.vim/.vimrc ~/.vimrc`
- `mv ~/.vim/.tmux.conf ~/.tmux.conf`
- `mv ~/.vim/.tmux.conf.local ~/.tmux.conf.local`
- 打开vim并执行bundle程序`:BundleInstall`
- 重新打开vim即可看到效果

### 了解更多vim使用的小技巧：

[tips.md](tips.md)

### 查看更新日志：

[`update_log.md`](update_log.md)

#终端复用模式
####vim模式下:
- `可在vim普通模式/插入模式中C-j下侧打开vim-tmux模式, C-l右侧打开vim-tmux模式`
- `更改C-a为tmux前缀(prefix), prefix + '-':横向拆分窗口, prefix + '\':纵向拆分窗口。`
- `prefix+(h,j,k,l)映射同vim下窗口之间移动. 同时也可使用鼠标切换窗口或者拖动鼠标改变窗口大小`
- ` C-c关闭vim-tmux模式 | prefix + & 关闭vim-tmux模式`
![screenshot.png](vim-tmux.png)

#####窗口分屏
- `横向分屏没有做任何映射，可根据需求，在配置文件中进行更改`
- `分屏大小可在.vim/bundle/screen/plugin/screen.vim 进行更改. 因个人审美观，需求，ScreenShellWidth被我设置为35`
- `更改配置请自行参考screen.txt`

#程序编译
####vim-tmux模式下, F5进行编译， F8进行gdb调试
![screenshot.png](vim-tmux-right.png)
![screenshot.png](vim-tmux-buttom.png)

#错误调试
## YouComplete+syntastic 自动补全，语法检测
- `自动补全，可用方向键，<tab> 键选择， 回车确定`
- `普通模式下：lo打开错误面板， lc关闭错误面板， ln跳转下一个出错位置，lp跳转上一个出错位置`
- `当错误发生时，光标停留在错误面板列表栏中， 回车选中你所需要更改的错误信息，ln, lp跳转`

![screenshot.png](vim-error.png)



